<?php
/**
 * WordPress Publisher
 *
 * Publishes generated articles to WordPress using wp_insert_post().
 * Supports two post types:
 *   - 'tutorial'  + 'tutorial_category' taxonomy  (longtail, trending, manual)
 *   - 'ai-tool'   + 'ai_tool_category' taxonomy   (tool deployment tutorials)
 *
 * @package QWE_Auto_Publish
 */

require_once __DIR__ . '/db.php';

class QWE_Publisher {

    /**
     * Publish an article to WordPress.
     *
     * @param array $article Article data from QWE_Generator.
     * @return int|false      Post ID on success, false on failure.
     */
    public static function publish( $article ) {

        // Ensure WordPress functions are available.
        if ( ! function_exists( 'wp_insert_post' ) ) {
            self::log( 'WordPress not loaded' );
            return false;
        }

        // Determine post type and taxonomy based on keyword_type.
        $is_tool   = ( 'tool' === ( $article['keyword_type'] ?? '' ) );
        $post_type = $is_tool ? QWE_TOOL_POST_TYPE : 'tutorial';
        $taxonomy  = $is_tool ? QWE_TOOL_TAXONOMY   : 'tutorial_category';

        // Sanitize slug first so duplicate check matches what WP actually stores.
        $slug = sanitize_title( $article['slug'] );

        // Check for duplicate slug.
        $existing = get_page_by_path( $slug, OBJECT, $post_type );
        if ( $existing ) {
            self::log( "Duplicate slug: {$slug}, skipping" );
            return false;
        }

        // Resolve a fixed author for this article (deterministic by slug).
        $author_id = self::resolve_random_author( $slug );

        // Get or create the category term.
        $term_id = self::get_or_create_category( $article['category'], $taxonomy );

        // Prepare post data.
        $post_data = array(
            'post_title'   => sanitize_text_field( $article['title'] ),
            'post_name'    => $slug,
            'post_content' => wp_kses_post( $article['content'] ),
            'post_excerpt' => sanitize_text_field( $article['excerpt'] ),
            'post_status'  => QWE_POST_STATUS,
            'post_type'    => $post_type,
            'post_author'  => $author_id,
        );

        // Insert the post.
        $post_id = wp_insert_post( $post_data, true );

        if ( is_wp_error( $post_id ) ) {
            self::log( 'wp_insert_post error: ' . $post_id->get_error_message() );
            return false;
        }

        // Assign category.
        if ( $term_id ) {
            wp_set_object_terms( $post_id, $term_id, $taxonomy );
        }

        // Assign tags (post_tag taxonomy).
        if ( ! empty( $article['tags'] ) && is_array( $article['tags'] ) ) {
            $clean_tags = array_map( 'sanitize_text_field', $article['tags'] );
            $clean_tags = array_filter( $clean_tags );
            if ( ! empty( $clean_tags ) ) {
                wp_set_post_tags( $post_id, $clean_tags );
            }
        }

        // Set difficulty level.
        update_post_meta( $post_id, '_qwe_difficulty', sanitize_text_field( $article['difficulty'] ) );

        // Save CTR-optimized meta description (used by seo.php for <meta name="description">).
        if ( ! empty( $article['meta_description'] ) ) {
            update_post_meta( $post_id, '_qwe_meta_description', sanitize_text_field( $article['meta_description'] ) );
        }

        // Don't auto-feature.
        update_post_meta( $post_id, '_qwe_featured', '0' );

        // Store keyword tracking meta.
        update_post_meta( $post_id, '_qwe_keyword_type', sanitize_text_field( $article['keyword_type'] ) );
        update_post_meta( $post_id, '_qwe_source_keyword', sanitize_text_field( $article['keyword'] ) );
        update_post_meta( $post_id, '_qwe_auto_generated', '1' );

        self::log( "Published: [{$post_id}] {$article['title']} ({$article['keyword_type']}: {$article['keyword']}) [{$post_type}]" );

        return $post_id;
    }

    /**
     * Get the term_id for a category slug, create if it doesn't exist.
     *
     * @param string $slug     Category slug from config.
     * @param string $taxonomy Taxonomy name.
     * @return int|false        Term ID or false.
     */
    private static function get_or_create_category( $slug, $taxonomy = 'tutorial_category' ) {
        $categories = unserialize( QWE_CATEGORIES );
        $name = isset( $categories[ $slug ] ) ? $categories[ $slug ] : $slug;

        $term = get_term_by( 'slug', $slug, $taxonomy );

        if ( $term ) {
            return $term->term_id;
        }

        // Create the term.
        $result = wp_insert_term( $name, $taxonomy, array(
            'slug' => $slug,
        ) );

        if ( is_wp_error( $result ) ) {
            self::log( "Failed to create category: {$slug} ({$taxonomy}) - " . $result->get_error_message() );
            return false;
        }

        return $result['term_id'];
    }

    /**
     * Deterministically pick an author name for this article and return its WP user ID.
     *
     * Uses a CRC32 hash of the post slug so the same article always maps to the
     * same author — even if the article is regenerated or the process retried.
     * Creates a minimal WP user for the name on first use.
     * Falls back to QWE_AUTHOR_ID if user creation fails.
     *
     * @param string $slug Post slug used as the stable hash key.
     * @return int WP user ID.
     */
    private static function resolve_random_author( $slug = '' ) {
        if ( ! defined( 'QWE_AUTHOR_POOL' ) ) {
            return QWE_AUTHOR_ID;
        }

        $pool = unserialize( QWE_AUTHOR_POOL );
        if ( empty( $pool ) ) {
            return QWE_AUTHOR_ID;
        }

        // Hash the slug so the same article always picks the same author.
        $pool   = array_values( $pool );
        $index  = abs( crc32( $slug ) ) % count( $pool );
        $display_name = $pool[ $index ];

        // Check if a WP user with this display name already exists.
        $users = get_users( array(
            'search'         => $display_name,
            'search_columns' => array( 'display_name' ),
            'number'         => 1,
            'fields'         => 'ids',
        ) );

        if ( ! empty( $users ) ) {
            self::log( "Author resolved: {$display_name} (user ID {$users[0]})" );
            return (int) $users[0];
        }

        // Create a new WP user for this author name.
        $slug     = sanitize_title( $display_name );
        $username = $slug . '_qwe';
        $email    = $slug . '@qwe-internal.local';

        $user_id = wp_insert_user( array(
            'user_login'   => $username,
            'user_pass'    => wp_generate_password( 24 ),
            'user_email'   => $email,
            'display_name' => $display_name,
            'role'         => 'author',
        ) );

        if ( is_wp_error( $user_id ) ) {
            self::log( "Failed to create author '{$display_name}': " . $user_id->get_error_message() . ' — using fallback ID' );
            return QWE_AUTHOR_ID;
        }

        self::log( "Author created: {$display_name} (user ID {$user_id})" );
        return $user_id;
    }

    /**
     * Simple log.
     */
    private static function log( $message ) {
        $time = date( 'Y-m-d H:i:s' );
        $log = "[{$time}] PUBLISHER: {$message}\n";
        file_put_contents( __DIR__ . '/data/auto_publish.log', $log, FILE_APPEND );
    }
}